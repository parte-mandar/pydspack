PyDSpack is a Data structure library which contains:

- Linked List
- Doubly Linked List
- Circular Linked List
- Stack
- Queue

Best for students learning and building Algorithms.
MIT Licenced